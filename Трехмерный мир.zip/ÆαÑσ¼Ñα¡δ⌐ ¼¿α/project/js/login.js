// Файл: login.js
document.addEventListener('DOMContentLoaded', function() {
  const loginForm = document.getElementById('loginForm');

  if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
      e.preventDefault();

      // Получаем значения полей
      const emailOrPhone = document.querySelector('#loginForm .input-field[type="text"]').value;
      const password = document.querySelector('#loginForm .input-field[type="password"]').value;

      // Простая валидация
      if (!emailOrPhone.trim()) {
        alert('Пожалуйста, введите email или телефон');
        return;
      }

      if (!password.trim()) {
        alert('Пожалуйста, введите пароль');
        return;
      }

      // === ДОБАВЛЯЕМ ДЕМО-ДАННЫЕ ДЛЯ ВХОДА ===
      // Демо пользователи для тестирования
      const demoUsers = {
        // Демо ученик
        'student@test.ru': {
          password: '123456',
          name: 'Иванов Иван Иванович',
          role: 'student',
          school: 'Гимназия №1',
          class: '8Б'
        },
        // Демо учитель
        'teacher@test.ru': {
          password: '123456',
          name: 'Петрова Анна Сергеевна',
          role: 'teacher',
          subject: '3D моделирование'
        },
        // Альтернативные варианты (для удобства)
        'ученик': { password: '123', name: 'Ученик Тестовый', role: 'student' },
        'учитель': { password: '123', name: 'Учитель Тестовый', role: 'teacher' },
        'test@mail.ru': { password: 'test123', name: 'Тест Пользователь', role: 'student' }
      };

      // Проверяем пользователя
      let user = null;

      // Проверка по email
      if (demoUsers[emailOrPhone.toLowerCase()]) {
        user = demoUsers[emailOrPhone.toLowerCase()];
      }
      // Проверка по русским названиям
      else if (emailOrPhone.toLowerCase() === 'ученик') {
        user = demoUsers['ученик'];
      }
      else if (emailOrPhone.toLowerCase() === 'учитель') {
        user = demoUsers['учитель'];
      }

      if (user && user.password === password) {
        // Сохраняем в localStorage
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('userRole', user.role);
        localStorage.setItem('userName', user.name);
        localStorage.setItem('userEmail', emailOrPhone);

        // Сохраняем дополнительные данные если есть
        if (user.school) localStorage.setItem('userSchool', user.school);
        if (user.class) localStorage.setItem('userClass', user.class);
        if (user.subject) localStorage.setItem('userSubject', user.subject);

        alert('Вход выполнен успешно!');

        // Перенаправление
        if (user.role === 'student') {
          window.location.href = 'ychenicy.html';
        } else {
          window.location.href = 'teacher.html';
        }
      } else {
        alert('Неверный email/телефон или пароль\n\n' +
              'Демо доступ:\n' +
              'Ученик: student@test.ru / 123456\n' +
              'Учитель: teacher@test.ru / 123456\n' +
              'Или просто: "ученик" / 123 или "учитель" / 123');
      }
    });
  }

  // Обработчик для ссылки "Забыли пароль?"
  const forgotPasswordLink = document.querySelector('.forgot-password a');
  if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener('click', function(e) {
      e.preventDefault();
      const email = prompt('Введите ваш email для восстановления пароля:');
      if (email) {
        alert(`Инструкции по восстановлению пароля отправлены на ${email}\n\n` +
              `Для демо-режима используйте:\n` +
              `Ученик: student@test.ru / 123456\n` +
              `Учитель: teacher@test.ru / 123456`);
      }
    });
  }

  // Автоматическое заполнение демо данных при нажатии на подсказку
  document.addEventListener('click', function(e) {
    if (e.target.tagName === 'A' && e.target.textContent.includes('Забыли пароль')) {
      // Не блокируем стандартное поведение, но показываем подсказку
      setTimeout(() => {
        const fillDemo = confirm('Заполнить демо данные для входа?');
        if (fillDemo) {
          const type = confirm('Выберите тип пользователя:\nOK - Ученик\nCancel - Учитель') ? 'student' : 'teacher';

          const emailField = document.querySelector('#loginForm .input-field[type="text"]');
          const passwordField = document.querySelector('#loginForm .input-field[type="password"]');

          if (type === 'student') {
            emailField.value = 'student@test.ru';
            passwordField.value = '123456';
          } else {
            emailField.value = 'teacher@test.ru';
            passwordField.value = '123456';
          }

          // Фокусируемся на кнопке входа
          document.querySelector('#loginForm .button').focus();
        }
      }, 100);
    }
  });
});
