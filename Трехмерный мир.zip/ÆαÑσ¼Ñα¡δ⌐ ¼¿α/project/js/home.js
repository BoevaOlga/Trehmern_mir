// js/home.js
document.addEventListener('DOMContentLoaded', function() {
    initHomePage();
});

function initHomePage() {
    // Получаем элементы
    const loginSquare = document.getElementById('loginSquare');
    const loginIcon = document.getElementById('loginIcon');
    const studentCard = document.getElementById('studentCard');
    const teacherCard = document.getElementById('teacherCard');
    const libraryCard = document.getElementById('libraryCard');
    const galleryCard = document.getElementById('galleryCard');
    const aboutCard = document.getElementById('aboutCard');

    // Проверяем авторизацию
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const userRole = localStorage.getItem('userRole');

    // Настраиваем кнопку входа/профиля
    if (isLoggedIn) {
        loginIcon.className = 'fas fa-user';
        loginSquare.title = 'Мой профиль';

        // Меняем действие в зависимости от роли
        if (userRole === 'teacher') {
            loginSquare.addEventListener('click', function() {
                window.location.href = 'teacher.html';
            });
        } else {
            loginSquare.addEventListener('click', function() {
                window.location.href = 'ychenicy.html';
            });
        }
    } else {
        loginSquare.addEventListener('click', function() {
            window.location.href = 'Vxod.html';
        });
    }

    // Настройка карточки ученика
    studentCard.addEventListener('click', function() {
        if (!isLoggedIn) {
            alert('Для доступа необходимо войти в систему');
            window.location.href = 'Vxod.html';
            return;
        }

        if (userRole !== 'student') {
            alert('Доступ запрещен. Эта панель только для учеников.');
            return;
        }

        window.location.href = 'ychenicy.html';
    });

    // Настройка карточки учителя
    teacherCard.addEventListener('click', function() {
        if (!isLoggedIn) {
            alert('Для доступа необходимо войти в систему');
            window.location.href = 'Vxod.html';
            return;
        }

        if (userRole !== 'teacher') {
            alert('Доступ запрещен. Эта панель только для учителей.');
            return;
        }

        window.location.href = 'teacher.html';
    });

    // Настройка карточки библиотеки (ОБУЧЕНИЕ)
    libraryCard.addEventListener('click', function() {
        window.location.href = 'Stranicha.html';
    });

    // Настройка карточки галереи
    galleryCard.addEventListener('click', function() {
        alert('Галерея работ находится в разработке. Скоро будет доступна!');
    });

    // Настройка карточки о проекте
    aboutCard.addEventListener('click', function() {
        alert('Образовательная платформа 3D моделирования\n\n' +
              'Версия 1.0\n' +
              '© 2024 Все права защищены\n\n' +
              'Платформа предназначена для обучения основам 3D моделирования.');
    });
}
