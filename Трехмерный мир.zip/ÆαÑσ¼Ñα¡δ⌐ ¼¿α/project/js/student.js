// js/student.js
// Логика страницы ученика

document.addEventListener('DOMContentLoaded', function() {
    console.log('🎯 Система 3D моделирования загружена');
    
    // Проверяем авторизацию
    if (!checkAuth() || localStorage.getItem('userRole') !== 'student') {
        alert('Доступ запрещен. Войдите как ученик.');
        window.location.href = 'Vxod.html';
        return;
    }
    
    // Основные элементы
    const bigSquare = document.querySelector('.big-square');
    const tabs = document.querySelectorAll('.top-rect');
    const tabContents = document.querySelectorAll('.tab-content');
    const squaresGrid = document.getElementById('squaresGrid');
    const addModelSquare = document.getElementById('addModelSquare');
    const uploadModelBtn = document.getElementById('uploadModelBtn');
    const modelModal = document.getElementById('modelModal');
    const modelFile = document.getElementById('modelFile');
    const confirmModelBtn = document.getElementById('confirmModelBtn');
    const cancelModelBtn = document.getElementById('cancelModelBtn');
    const viewerModal = document.getElementById('viewerModal');
    const closeViewerBtn = document.getElementById('closeViewerBtn');
    const logoutBtn = document.getElementById('topLogoutBtn');
    
    // Three.js переменные
    let scene, camera, renderer, controls, currentModel = null;
    let isRotating = false;
    
    // Данные
    let models = [];
    let selectedFile = null;
    let modelCounter = 1;
    let currentRow = 1;
    
    // Инициализация
    initStudentPage();
    
    function initStudentPage() {
        // Инициализация вкладок
        initTabs();
        
        // Инициализация загрузки файлов
        initFileUpload();
        
        // Инициализация просмотрщика
        initViewer();
        
        // Загрузка сохраненных моделей
        loadModels();
        
        // Инициализация фото профиля
        initProfilePhoto();
        
        // Инициализация сохранения профиля
        initProfileSave();
        
        // Инициализация кнопки выхода
        initLogoutButton();
        
        // Обновление имени пользователя
        updateUserName();
        
        console.log('✅ Страница ученика инициализирована');
    }
    
    function initTabs() {
        tabs.forEach(tab => {
            tab.addEventListener('click', function() {
                tabs.forEach(t => t.classList.remove('active'));
                tabContents.forEach(c => c.classList.remove('active'));
                this.classList.add('active');
                const tabId = this.getAttribute('data-tab');
                document.getElementById(tabId + 'Tab').classList.add('active');
            });
        });
    }
    
    function initFileUpload() {
        addModelSquare.addEventListener('click', () => modelModal.classList.add('active'));
        uploadModelBtn.addEventListener('click', () => modelModal.classList.add('active'));
        
        modelFile.addEventListener('change', function(e) {
            if (e.target.files[0]) {
                selectedFile = e.target.files[0];
                
                if (!selectedFile.name.toLowerCase().endsWith('.stl') &&
                    !selectedFile.name.toLowerCase().endsWith('.obj') &&
                    !selectedFile.name.toLowerCase().endsWith('.m3d')) {
                    alert('Принимаются файлы: .stl, .obj, .m3d');
                    modelFile.value = '';
                    return;
                }
                
                document.getElementById('fileName').textContent = selectedFile.name;
                document.getElementById('fileSize').textContent = formatFileSize(selectedFile.size);
                document.getElementById('fileType').textContent = selectedFile.name.split('.').pop().toUpperCase();
                document.getElementById('fileInfo').style.display = 'block';
            }
        });
        
        confirmModelBtn.addEventListener('click', function() {
            if (!selectedFile) {
                showAlert('Выберите файл', 'error');
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(e) {
                const modelData = {
                    id: modelCounter++,
                    name: selectedFile.name,
                    size: selectedFile.size,
                    date: new Date().toLocaleString('ru-RU'),
                    data: e.target.result
                };
                
                models.push(modelData);
                createModelCard(modelData);
                saveModels();
                
                modelModal.classList.remove('active');
                selectedFile = null;
                modelFile.value = '';
                document.getElementById('fileInfo').style.display = 'none';
                
                showAlert(`Модель "${selectedFile.name}" загружена!`, 'success');
                
                if (window.submitModelToTeacher) {
                    window.submitModelToTeacher(modelData);
                }
            };
            
            reader.readAsDataURL(selectedFile);
        });
        
        cancelModelBtn.addEventListener('click', () => {
            modelModal.classList.remove('active');
            selectedFile = null;
            modelFile.value = '';
            document.getElementById('fileInfo').style.display = 'none';
        });
        
        modelModal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
                selectedFile = null;
                modelFile.value = '';
                document.getElementById('fileInfo').style.display = 'none';
            }
        });
    }
    
    function initViewer() {
        initThreeJS();
        
        const rotateBtn = document.getElementById('rotateBtn');
        const zoomInBtn = document.getElementById('zoomInBtn');
        const zoomOutBtn = document.getElementById('zoomOutBtn');
        const resetBtn = document.getElementById('resetViewBtn');
        
        if (rotateBtn) {
            rotateBtn.addEventListener('click', function() {
                isRotating = !isRotating;
                this.classList.toggle('active');
                this.innerHTML = isRotating ? 
                    '<i class="fas fa-pause"></i> Пауза' : 
                    '<i class="fas fa-sync-alt"></i> Вращать';
            });
        }
        
        if (zoomInBtn) {
            zoomInBtn.addEventListener('click', () => {
                if (camera) {
                    camera.zoom *= 1.2;
                    camera.updateProjectionMatrix();
                }
            });
        }
        
        if (zoomOutBtn) {
            zoomOutBtn.addEventListener('click', () => {
                if (camera) {
                    camera.zoom *= 0.8;
                    camera.updateProjectionMatrix();
                }
            });
        }
        
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                if (camera && currentModel) {
                    isRotating = false;
                    if (rotateBtn) rotateBtn.classList.remove('active');
                    
                    camera.zoom = 1;
                    camera.updateProjectionMatrix();
                    
                    const box = new THREE.Box3().setFromObject(currentModel);
                    const center = box.getCenter(new THREE.Vector3());
                    
                    camera.position.set(10, 10, 10);
                    camera.lookAt(center);
                    
                    if (controls) controls.target.copy(center);
                    
                    if (currentModel) currentModel.rotation.set(0, 0, 0);
                    
                    showAlert('Вид сброшен', 'info');
                }
            });
        }
        
        closeViewerBtn.addEventListener('click', () => {
            viewerModal.classList.remove('active');
            isRotating = false;
        });
        
        viewerModal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
                isRotating = false;
            }
        });
    }
    
    function initThreeJS() {
        if (typeof THREE === 'undefined') {
            console.error('❌ Three.js не загружен');
            return false;
        }
        
        const container = document.getElementById('threejsViewer');
        if (!container) return false;
        
        try {
            container.innerHTML = '';
            
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0xf8f9fa);
            
            const width = container.clientWidth;
            const height = container.clientHeight;
            camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
            camera.position.set(10, 10, 10);
            
            renderer = new THREE.WebGLRenderer({ 
                antialias: true,
                alpha: true
            });
            renderer.setSize(width, height);
            container.appendChild(renderer.domElement);
            
            if (typeof THREE.OrbitControls !== 'undefined') {
                controls = new THREE.OrbitControls(camera, renderer.domElement);
                controls.enableDamping = true;
                controls.dampingFactor = 0.05;
            }
            
            const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
            scene.add(ambientLight);
            
            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
            directionalLight.position.set(10, 20, 10);
            scene.add(directionalLight);
            
            function animate() {
                requestAnimationFrame(animate);
                
                if (controls) {
                    controls.update();
                }
                
                if (currentModel && isRotating) {
                    currentModel.rotation.y += 0.01;
                }
                
                renderer.render(scene, camera);
            }
            animate();
            
            console.log('✅ Three.js инициализирован');
            return true;
            
        } catch (error) {
            console.error('❌ Ошибка инициализации Three.js:', error);
            return false;
        }
    }
    
    function initProfilePhoto() {
        if (bigSquare) {
            bigSquare.addEventListener('click', function() {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = 'image/*';
                input.onchange = function(e) {
                    if (e.target.files[0]) {
                        const reader = new FileReader();
                        reader.onload = function(event) {
                            const img = document.getElementById('uploadedPhoto');
                            if (img) {
                                img.src = event.target.result;
                                bigSquare.classList.add('has-photo');
                            }
                        };
                        reader.readAsDataURL(e.target.files[0]);
                    }
                };
                input.click();
            });
        }
    }
    
    function initProfileSave() {
        const saveBtn = document.getElementById('saveProfile');
        if (saveBtn) {
            saveBtn.addEventListener('click', function() {
                const lastName = document.getElementById('lastName').value;
                const firstName = document.getElementById('firstName').value;
                const middleName = document.getElementById('middleName').value;
                
                localStorage.setItem('userName', `${lastName} ${firstName} ${middleName}`);
                updateUserName();
                showAlert('Профиль сохранен', 'success');
            });
        }
    }
    
    function initLogoutButton() {
        if (logoutBtn) {
            logoutBtn.addEventListener('click', function(e) {
                e.preventDefault();
                if (confirm('Вы уверены, что хотите выйти из системы?')) {
                    logout();
                }
            });
        }
    }
    
    function updateUserName() {
        const userName = localStorage.getItem('userName') || 'Ученик';
        const displayName = document.getElementById('displayName');
        if (displayName) {
            displayName.textContent = userName;
        }
    }
    
    // ============ ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ============
    
    function createModelCard(modelData) {
        const row = document.getElementById(`row-${currentRow}`);
        let rowItems = row ? row.querySelectorAll('.model-square:not(.add-square)') : [];
        
        if (rowItems.length >= 3) {
            currentRow++;
            const newRow = document.createElement('div');
            newRow.className = 'grid-row';
            newRow.id = `row-${currentRow}`;
            squaresGrid.appendChild(newRow);
            rowItems = [];
        }
        
        const modelSquare = document.createElement('div');
        modelSquare.className = 'model-square';
        modelSquare.setAttribute('data-id', modelData.id);
        
        const previewIcon = document.createElement('div');
        previewIcon.className = 'model-preview-icon';
        previewIcon.innerHTML = '<i class="fas fa-cube"></i>';
        
        const modelName = document.createElement('div');
        modelName.className = 'model-name';
        modelName.textContent = modelData.name.split('.')[0];
        
        const modelSize = document.createElement('div');
        modelSize.className = 'model-size';
        modelSize.textContent = formatFileSize(modelData.size);
        
        const deleteBtn = document.createElement('div');
        deleteBtn.className = 'delete-model';
        deleteBtn.innerHTML = '×';
        deleteBtn.onclick = function(e) {
            e.stopPropagation();
            if (confirm(`Удалить модель "${modelData.name}"?`)) {
                models = models.filter(m => m.id !== modelData.id);
                modelSquare.remove();
                saveModels();
                showAlert('Модель удалена', 'info');
            }
        };
        
        modelSquare.appendChild(previewIcon);
        modelSquare.appendChild(modelName);
        modelSquare.appendChild(modelSize);
        modelSquare.appendChild(deleteBtn);
        
        modelSquare.onclick = function() {
            showModel(modelData);
        };
        
        const currentRowEl = document.getElementById(`row-${currentRow}`);
        const addSquare = currentRowEl.querySelector('.add-square');
        currentRowEl.insertBefore(modelSquare, addSquare);
    }
    
    function loadModels() {
        const savedModels = localStorage.getItem('studentModels');
        if (savedModels) {
            try {
                models = JSON.parse(savedModels);
                modelCounter = models.length > 0 ? Math.max(...models.map(m => m.id)) + 1 : 1;
                
                models.forEach(model => {
                    createModelCard(model);
                });
                
                console.log(`✅ Загружено ${models.length} моделей`);
            } catch (e) {
                console.error('Ошибка загрузки моделей:', e);
            }
        }
    }
    
    function saveModels() {
        localStorage.setItem('studentModels', JSON.stringify(models));
    }
    
    function showModel(modelData) {
        viewerModal.classList.add('active');
        
        document.getElementById('viewerModelName').textContent = modelData.name;
        document.getElementById('viewerModelSize').textContent = formatFileSize(modelData.size);
        document.getElementById('viewerModelDate').textContent = modelData.date;
        
        loadSTLModel(modelData.data);
    }
    
    function loadSTLModel(dataURL) {
        if (!scene) {
            console.error('Сцена не инициализирована');
            return;
        }
        
        if (currentModel) {
            scene.remove(currentModel);
        }
        
        try {
            const geometry = new THREE.BoxGeometry(3, 3, 3);
            const material = new THREE.MeshPhongMaterial({ 
                color: 0x3D7BBA,
                shininess: 30
            });
            
            currentModel = new THREE.Mesh(geometry, material);
            scene.add(currentModel);
            
            const box = new THREE.Box3().setFromObject(currentModel);
            const center = box.getCenter(new THREE.Vector3());
            
            camera.position.set(10, 10, 10);
            camera.lookAt(center);
            
            if (controls) {
                controls.target.copy(center);
            }
            
            console.log('✅ Модель загружена в просмотрщик');
        } catch (error) {
            console.error('Ошибка загрузки модели:', error);
            showAlert('Ошибка загрузки модели', 'error');
        }
    }
    
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    function showAlert(message, type = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 8px;
            color: white;
            font-weight: 500;
            z-index: 10000;
            animation: slideIn 0.3s ease;
            max-width: 300px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        `;
        
        if (type === 'success') {
            alertDiv.style.background = '#2ecc71';
        } else if (type === 'error') {
            alertDiv.style.background = '#e74c3c';
        } else if (type === 'info') {
            alertDiv.style.background = '#3498db';
        } else {
            alertDiv.style.background = '#3D7BBA';
        }
        
        alertDiv.textContent = message;
        document.body.appendChild(alertDiv);
        
        setTimeout(() => {
            alertDiv.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.parentNode.removeChild(alertDiv);
                }
            }, 300);
        }, 3000);
    }
    
    function logout() {
        localStorage.removeItem('isLoggedIn');
        localStorage.removeItem('userRole');
        localStorage.removeItem('userName');
        localStorage.removeItem('studentModels');
        
        showAlert('Вы успешно вышли из системы', 'info');
        
        setTimeout(() => {
            window.location.href = 'Vxod.html';
        }, 1500);
    }
    
    if (!document.querySelector('#alert-styles')) {
        const style = document.createElement('style');
        style.id = 'alert-styles';
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
});

// Функция проверки авторизации
function checkAuth() {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const userRole = localStorage.getItem('userRole');
    return isLoggedIn === 'true' && userRole === 'student';
}