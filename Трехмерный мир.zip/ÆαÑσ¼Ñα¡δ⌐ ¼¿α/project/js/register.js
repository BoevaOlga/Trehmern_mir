document.addEventListener('DOMContentLoaded', function() {
  // Элементы
  const emailButton = document.getElementById('emailButton');
  const phoneButton = document.getElementById('phoneButton');
  const emailField = document.getElementById('emailField');
  const phoneField = document.getElementById('phoneField');
  const emailInput = document.getElementById('emailInput');
  const phoneInput = document.getElementById('phoneInput');
  const passwordInput = document.getElementById('passwordInput');
  const registerButton = document.getElementById('registerButton');

  const mainCard = document.getElementById('mainCard');
  const codeCard = document.getElementById('codeCard');
  const codeDestination = document.getElementById('codeDestination');
  const codeInputs = document.querySelectorAll('.code-input');
  const verifyCodeButton = document.getElementById('verifyCodeButton');
  const resendCode = document.getElementById('resendCode');

  const step1 = document.getElementById('step1');
  const step2 = document.getElementById('step2');
  const lastName = document.getElementById('lastName');
  const firstName = document.getElementById('firstName');
  const middleName = document.getElementById('middleName');
  const birthDay = document.getElementById('birthDay');
  const birthMonth = document.getElementById('birthMonth');
  const birthYear = document.getElementById('birthYear');
  const school = document.getElementById('school');
  const classNumber = document.getElementById('classNumber');
  const completeButton = document.getElementById('completeButton');

  let selectedMethod = 'email';
  let confirmationCode = '';
  let userContact = '';

  // Инициализация
  init();

  function init() {
    // Заполняем даты
    fillDateSelects();

    // События переключателя
    emailButton.addEventListener('click', function() {
      selectMethod('email');
    });

    phoneButton.addEventListener('click', function() {
      selectMethod('phone');
    });

    // Маска телефона
    phoneInput.addEventListener('input', function(e) {
      let value = this.value.replace(/\D/g, '');

      if (value.length === 0) return;

      if (value.length === 1 && value !== '7' && value !== '8') {
        value = '7' + value;
      }

      if (value.length > 0 && value[0] === '8') {
        value = '7' + value.substring(1);
      }

      let formattedValue = '+7';

      if (value.length > 1) {
        formattedValue += ' (' + value.substring(1, 4);
      }
      if (value.length >= 5) {
        formattedValue += ') ' + value.substring(4, 7);
      }
      if (value.length >= 8) {
        formattedValue += '-' + value.substring(7, 9);
      }
      if (value.length >= 10) {
        formattedValue += '-' + value.substring(9, 11);
      }

      this.value = formattedValue;
    });

    // Автозаполнение демо-данных при двойном клике на поле email
    emailInput.addEventListener('dblclick', function() {
      if (confirm('Заполнить демо email для тестирования?')) {
        this.value = 'test.user@school.ru';
        passwordInput.value = '123456';
        alert('Демо данные заполнены!\nEmail: test.user@school.ru\nПароль: 123456');
      }
    });

    // Регистрация
    registerButton.addEventListener('click', handleRegistration);

    // Код
    codeInputs.forEach((input, index) => {
      input.addEventListener('input', function() {
        const value = this.value;

        if (!/^\d?$/.test(value)) {
          this.value = '';
          return;
        }

        if (value && index < 5) {
          codeInputs[index + 1].focus();
        }
      });

      input.addEventListener('keydown', function(e) {
        if (e.key === 'Backspace' && !this.value && index > 0) {
          codeInputs[index - 1].focus();
        }
      });
    });

    verifyCodeButton.addEventListener('click', verifyCode);
    resendCode.addEventListener('click', generateCode);
    completeButton.addEventListener('click', completeRegistration);
  }

  function fillDateSelects() {
    // Дни
    for (let i = 1; i <= 31; i++) {
      const option = document.createElement('option');
      option.value = i;
      option.textContent = i;
      birthDay.appendChild(option);
    }

    // Годы (от 2000 до текущего)
    const currentYear = new Date().getFullYear();
    for (let i = currentYear; i >= 2000; i--) {
      const option = document.createElement('option');
      option.value = i;
      option.textContent = i;
      birthYear.appendChild(option);
    }

    // Заполняем по умолчанию (15 лет) - для демо
    birthYear.value = currentYear - 15;
    birthMonth.value = '6';
    birthDay.value = '15';

    // Автозаполнение демо-данных
    school.value = 'Гимназия №1';
    classNumber.value = '8';
    lastName.value = 'Иванов';
    firstName.value = 'Иван';
    middleName.value = 'Иванович';
  }

  function selectMethod(method) {
    if (method === selectedMethod) return;

    selectedMethod = method;

    // Обновляем кнопки
    emailButton.classList.toggle('active', method === 'email');
    phoneButton.classList.toggle('active', method === 'phone');

    // Прячем ненужное поле и показываем нужное
    if (method === 'email') {
      // Скрываем телефон
      phoneField.style.opacity = '0';
      phoneField.style.transform = 'translateY(-20px)';

      // После анимации скрытия показываем email
      setTimeout(() => {
        phoneField.style.display = 'none';
        emailField.style.display = 'block';

        // Запускаем анимацию появления email
        setTimeout(() => {
          emailField.style.opacity = '1';
          emailField.style.transform = 'translateY(0)';
          emailInput.focus();
        }, 10);
      }, 300);
    } else {
      // Скрываем email
      emailField.style.opacity = '0';
      emailField.style.transform = 'translateY(-20px)';

      // После анимации скрытия показываем телефон
      setTimeout(() => {
        emailField.style.display = 'none';
        phoneField.style.display = 'block';

        // Запускаем анимацию появления телефона
        setTimeout(() => {
          phoneField.style.opacity = '1';
          phoneField.style.transform = 'translateY(0)';
          phoneInput.focus();
        }, 10);
      }, 300);
    }

    // Очищаем поля
    if (method === 'email') {
      phoneInput.value = '';
    } else {
      emailInput.value = '';
    }
  }

  function handleRegistration() {
    // Получаем данные
    const currentInput = selectedMethod === 'email' ? emailInput : phoneInput;
    userContact = currentInput.value.trim();
    const password = passwordInput.value.trim();

    // Валидация
    if (selectedMethod === 'email') {
      if (!userContact || !userContact.includes('@') || !userContact.includes('.')) {
        alert('Введите корректный email');
        emailInput.focus();
        return;
      }
    } else {
      if (!userContact || userContact.replace(/\D/g, '').length < 11) {
        alert('Введите полный номер телефона');
        phoneInput.focus();
        return;
      }
    }

    if (!password || password.length < 6) {
      alert('Пароль должен быть не менее 6 символов');
      passwordInput.focus();
      return;
    }

    // Показываем отдельное окно с кодом
    showCodeWindow();
  }

  function showCodeWindow() {
    // Затемняем фон
    document.querySelector('.page').classList.add('code-visible');

    // Показываем окно с кодом
    codeDestination.textContent = userContact;
    codeCard.style.display = 'block';

    // Анимация появления
    setTimeout(() => {
      codeCard.style.opacity = '1';
      codeCard.style.transform = 'translate(-50%, -50%) scale(1)';
    }, 10);

    // Генерируем код
    generateCode();
  }

  function hideCodeWindow() {
    // Убираем затемнение
    document.querySelector('.page').classList.remove('code-visible');

    // Анимация скрытия
    codeCard.style.opacity = '0';
    codeCard.style.transform = 'translate(-50%, -50%) scale(0.9)';

    setTimeout(() => {
      codeCard.style.display = 'none';
    }, 300);
  }

  function generateCode() {
    // Простой 6-значный код
    confirmationCode = '';
    for (let i = 0; i < 6; i++) {
      confirmationCode += Math.floor(Math.random() * 10);
    }

    // Для тестирования показываем код
    console.log('Код подтверждения:', confirmationCode);
    alert(`Код для тестирования: ${confirmationCode}\n\nВведите этот код в поля подтверждения.`);

    // Очищаем поля кода
    codeInputs.forEach(input => input.value = '');
    codeInputs[0].focus();
  }

  function verifyCode() {
    const enteredCode = Array.from(codeInputs).map(input => input.value).join('');

    if (enteredCode === confirmationCode) {
      // Скрываем окно с кодом
      hideCodeWindow();

      // Скрываем шаг 1 с анимацией
      step1.style.opacity = '0';
      step1.style.transform = 'translateY(-20px)';

      setTimeout(() => {
        step1.style.display = 'none';
        step2.style.display = 'block';

        // Показываем шаг 2 с анимацией
        setTimeout(() => {
          step2.style.opacity = '1';
          step2.style.transform = 'translateY(0)';
        }, 10);
      }, 300);
    } else {
      alert('Неверный код');
      codeInputs.forEach(input => input.value = '');
      codeInputs[0].focus();
    }
  }

  function completeRegistration() {
    // Проверяем поля
    if (!lastName.value.trim() || !firstName.value.trim() || !school.value.trim() || !classNumber.value) {
      alert('Заполните все обязательные поля');
      return;
    }

    // Сохраняем данные
    const userData = {
      contact: userContact,
      method: selectedMethod,
      lastName: lastName.value.trim(),
      firstName: firstName.value.trim(),
      middleName: middleName.value.trim(),
      birthDate: {
        day: birthDay.value,
        month: birthMonth.value,
        year: birthYear.value
      },
      school: school.value.trim(),
      class: classNumber.value,
      registered: new Date().toISOString()
    };

    localStorage.setItem('userData', JSON.stringify(userData));

    // Показываем успех
    completeButton.textContent = '✓ Успешно!';
    completeButton.style.background = 'linear-gradient(to right, #4CAF50, #2E7D32)';
    completeButton.disabled = true;

    setTimeout(() => {
      alert('Регистрация завершена! Теперь вы можете войти в систему.');
      window.location.href = 'Vxod.html';
    }, 1000);
  }
});