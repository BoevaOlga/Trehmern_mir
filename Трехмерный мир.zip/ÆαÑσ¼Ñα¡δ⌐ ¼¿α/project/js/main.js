// js/main.js - добавляем функцию загрузки данных пользователя

// ... существующий код ...

// Функция загрузки данных пользователя на страницу
function loadUserDataToPage() {
    const userName = localStorage.getItem('userName');
    const userRole = localStorage.getItem('userRole');
    const userEmail = localStorage.getItem('userEmail');
    const userSchool = localStorage.getItem('userSchool');
    const userClass = localStorage.getItem('userClass');

    // Обновляем имя пользователя если есть элемент для этого
    const nameElements = document.querySelectorAll('#userName, #teacherName, #studentName, .user-name, [data-user="name"]');
    nameElements.forEach(el => {
        if (userName) el.textContent = userName;
    });

    // Обновляем email если есть поле
    const emailElements = document.querySelectorAll('#userEmail, #email, [data-user="email"]');
    emailElements.forEach(el => {
        if (userEmail) el.textContent = userEmail;
    });

    // Обновляем школу и класс для ученика
    if (userRole === 'student') {
        const schoolInput = document.getElementById('school');
        const classInput = document.getElementById('class');

        if (schoolInput && userSchool) schoolInput.value = userSchool;
        if (classInput && userClass) classInput.value = userClass;
    }

    // Показываем роль пользователя
    const roleElements = document.querySelectorAll('#userRole, .user-role, [data-user="role"]');
    roleElements.forEach(el => {
        if (userRole) {
            el.textContent = userRole === 'teacher' ? 'Учитель' : 'Ученик';
        }
    });
}

// Вызываем при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    loadAppState();
    loadUserDataToPage();

    // Если пользователь залогинен, показываем приветствие
    if (appState.isLoggedIn && appState.userName) {
        console.log(`Добро пожаловать, ${appState.userName} (${appState.userRole})`);
    }
});
