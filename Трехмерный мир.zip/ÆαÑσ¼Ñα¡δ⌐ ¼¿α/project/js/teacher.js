// Данные учителя
let teacherData = {
    name: "Иванова Анна Петровна",
    subject: "Учитель 3D моделирования",
    groups: [],
    students: [],
    models: [],
    homework: []
};

// Текущее состояние
let currentState = {
    activeSection: 'dashboard',
    currentModelId: null,
    filterModel: 'all'
};

// Инициализация приложения
function initTeacherApp() {
    console.log('Инициализация панели учителя...');
    
    // Загрузка данных
    loadFromStorage();
    loadTeacherData();
    
    // Настройка интерфейса
    setupNavigation();
    setupEventListeners();
    
    // Загрузка начальных данных
    loadDashboardData();
    
    console.log('Панель учителя готова!');
}

// Загрузка данных из localStorage
function loadFromStorage() {
    try {
        const savedTeacher = localStorage.getItem('teacherData');
        if (savedTeacher) {
            const parsed = JSON.parse(savedTeacher);
            teacherData = { ...teacherData, ...parsed };
        }

        // Загрузка моделей учеников
        loadStudentModelsFromStorage();
        
        // Создание демо данных если нет реальных
        if (teacherData.students.length === 0) {
            createDemoData();
        }
        
        saveTeacherData();
        
    } catch (error) {
        console.error('Ошибка загрузки данных:', error);
        showToast('Ошибка загрузки данных', 'error');
    }
}

// Создание демо данных
function createDemoData() {
    console.log('Создание демо данных...');
    
    teacherData.students = [
        {
            id: 1,
            name: "Иванов Иван Иванович",
            group: "8А",
            school: "Гимназия №1",
            models: 3,
            status: "active"
        },
        {
            id: 2,
            name: "Петров Петр Петрович",
            group: "8А",
            school: "Гимназия №1",
            models: 2,
            status: "active"
        }
    ];

    teacherData.groups = [
        {
            id: 1,
            name: "8А класс",
            code: "8A-2024-123",
            description: "Основная группа 8А класса",
            students: [1, 2],
            created: new Date().toISOString()
        }
    ];

    teacherData.models = [
        {
            id: 1,
            name: "house_model.stl",
            studentId: 1,
            studentName: "Иванов Иван Иванович",
            group: "8А",
            size: "2.4 MB",
            date: new Date().toLocaleDateString('ru-RU'),
            status: "pending",
            fileType: ".stl"
        },
        {
            id: 2,
            name: "car_model.obj",
            studentId: 2,
            studentName: "Петров Петр Петрович",
            group: "8А",
            size: "1.8 MB",
            date: new Date().toLocaleDateString('ru-RU'),
            status: "approved",
            fileType: ".obj"
        }
    ];

    teacherData.homework = [
        {
            id: 1,
            title: "Создание 3D модели дома",
            description: "Создайте простую 3D модель дома",
            dueDate: "2024-02-01",
            group: "8А",
            created: new Date().toISOString().split('T')[0],
            submissions: 2
        }
    ];
}

// Загрузка моделей учеников из хранилища
function loadStudentModelsFromStorage() {
    try {
        const sharedModels = localStorage.getItem('teacher_student_models');
        if (sharedModels) {
            const models = JSON.parse(sharedModels);
            
            models.forEach(sharedModel => {
                const newModel = {
                    id: teacherData.models.length + 1,
                    name: sharedModel.model.name,
                    studentId: sharedModel.studentId,
                    studentName: sharedModel.studentName,
                    group: sharedModel.model.group || 'Не указана',
                    size: sharedModel.model.size,
                    date: sharedModel.model.date,
                    status: sharedModel.model.status || 'pending',
                    fileType: sharedModel.model.fileType
                };
                
                teacherData.models.push(newModel);
            });
        }
    } catch (error) {
        console.error('Ошибка загрузки моделей учеников:', error);
    }
}

// Сохранение данных учителя
function saveTeacherData() {
    try {
        localStorage.setItem('teacherData', JSON.stringify(teacherData));
    } catch (error) {
        console.error('Ошибка сохранения данных:', error);
    }
}

// Загрузка данных учителя в интерфейс
function loadTeacherData() {
    document.getElementById('teacherName').textContent = teacherData.name;
    document.getElementById('teacherSubject').textContent = teacherData.subject;
}

// Настройка навигации
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const section = this.getAttribute('data-section');
            
            // Удаляем активный класс у всех ссылок
            navLinks.forEach(l => l.classList.remove('active'));
            
            // Добавляем активный класс текущей ссылке
            this.classList.add('active');
            
            // Переключаем секции
            switchSection(section);
        });
    });
}

// Переключение секций
function switchSection(sectionId) {
    // Скрываем все секции
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Показываем выбранную секцию
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        currentState.activeSection = sectionId;
        
        // Загружаем данные для секции
        switch(sectionId) {
            case 'dashboard':
                loadDashboardData();
                break;
            case 'groups':
                loadGroupsData();
                break;
            case 'students':
                loadStudentsData();
                break;
            case 'models':
                loadModelsData();
                break;
            case 'homework':
                loadHomeworkData();
                break;
        }
    }
}

// Настройка обработчиков событий
function setupEventListeners() {
    // Кнопка обновления
    document.getElementById('refreshBtn')?.addEventListener('click', loadDashboardData);
    
    // Кнопка выхода
    document.getElementById('logoutBtn')?.addEventListener('click', function() {
        if (confirm('Выйти из панели учителя?')) {
            localStorage.removeItem('teacherData');
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('userName');
            localStorage.removeItem('userRole');
            window.location.href = 'Vxod.html'; // Ведет на страницу входа
        }
    });
    
    // Модальные окна
    setupModals();
    
    // Поиск и фильтры
    setupSearchAndFilters();
}

// Модальные окна
function setupModals() {
    // Создание группы
    const groupModal = document.getElementById('groupModal');
    const createGroupBtn = document.getElementById('createGroupBtn');
    const saveGroupBtn = document.getElementById('saveGroupBtn');
    const cancelGroupBtn = document.getElementById('cancelGroupBtn');
    const closeGroupModal = document.getElementById('closeGroupModal');
    
    createGroupBtn?.addEventListener('click', showGroupModal);
    saveGroupBtn?.addEventListener('click', saveNewGroup);
    cancelGroupBtn?.addEventListener('click', () => groupModal.classList.remove('active'));
    closeGroupModal?.addEventListener('click', () => groupModal.classList.remove('active'));
    
    // Создание задания
    const homeworkModal = document.getElementById('homeworkModal');
    const createHomeworkBtn = document.getElementById('createHomeworkBtn');
    const saveHomeworkBtn = document.getElementById('saveHomeworkBtn');
    const cancelHomeworkBtn = document.getElementById('cancelHomeworkBtn');
    const closeHomeworkModal = document.getElementById('closeHomeworkModal');
    
    createHomeworkBtn?.addEventListener('click', showHomeworkModal);
    saveHomeworkBtn?.addEventListener('click', saveNewHomework);
    cancelHomeworkBtn?.addEventListener('click', () => homeworkModal.classList.remove('active'));
    closeHomeworkModal?.addEventListener('click', () => homeworkModal.classList.remove('active'));
    
    // Добавление ученика
    const studentModal = document.getElementById('studentModal');
    const addStudentBtn = document.getElementById('addStudentBtn');
    const saveStudentBtn = document.getElementById('saveStudentBtn');
    const cancelStudentBtn = document.getElementById('cancelStudentBtn');
    const closeStudentModal = document.getElementById('closeStudentModal');
    
    addStudentBtn?.addEventListener('click', showStudentModal);
    saveStudentBtn?.addEventListener('click', saveNewStudent);
    cancelStudentBtn?.addEventListener('click', () => studentModal.classList.remove('active'));
    closeStudentModal?.addEventListener('click', () => studentModal.classList.remove('active'));
    
    // Просмотр модели
    const modelViewModal = document.getElementById('modelViewModal');
    const closeModelBtn = document.getElementById('closeModelBtn');
    const closeViewerBtn = document.getElementById('closeViewerBtn');
    const approveModelBtn = document.getElementById('approveModelBtn');
    const rejectModelBtn = document.getElementById('rejectModelBtn');
    
    closeModelBtn?.addEventListener('click', () => modelViewModal.classList.remove('active'));
    closeViewerBtn?.addEventListener('click', () => modelViewModal.classList.remove('active'));
    approveModelBtn?.addEventListener('click', approveCurrentModel);
    rejectModelBtn?.addEventListener('click', rejectCurrentModel);
    
    // Закрытие модалок по клику вне контента
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
            }
        });
    });
}

// Поиск и фильтры
function setupSearchAndFilters() {
    // Поиск групп
    const searchGroups = document.getElementById('searchGroups');
    searchGroups?.addEventListener('input', function(e) {
        filterGroups(e.target.value);
    });
    
    // Поиск учеников
    const searchStudents = document.getElementById('searchStudents');
    searchStudents?.addEventListener('input', function(e) {
        filterStudents(e.target.value);
    });
    
    // Фильтры моделей
    const filterTabs = document.querySelectorAll('.filter-tab');
    filterTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            // Обновляем активную вкладку
            filterTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // Применяем фильтр
            currentState.filterModel = filter;
            loadModelsData();
        });
    });
}

// Загрузка данных главной панели
function loadDashboardData() {
    // Статистика
    document.getElementById('totalGroups').textContent = teacherData.groups.length;
    document.getElementById('totalStudents').textContent = teacherData.students.length;
    document.getElementById('totalModels').textContent = teacherData.models.length;
    
    const pendingModels = teacherData.models.filter(m => m.status === 'pending').length;
    document.getElementById('pendingReviews').textContent = pendingModels;
}

// Показать модальное окно создания группы
function showGroupModal() {
    const modal = document.getElementById('groupModal');
    modal.classList.add('active');
    
    // Сброс формы
    document.getElementById('groupNameInput').value = '';
    document.getElementById('groupDescription').value = '';
}

// Сохранение новой группы
function saveNewGroup() {
    const name = document.getElementById('groupNameInput').value.trim();
    const description = document.getElementById('groupDescription').value.trim();
    
    if (!name) {
        showToast('Введите название группы', 'warning');
        return;
    }
    
    const newGroup = {
        id: teacherData.groups.length + 1,
        name: name,
        code: generateGroupCode(name),
        description: description,
        students: [],
        created: new Date().toISOString()
    };
    
    teacherData.groups.push(newGroup);
    saveTeacherData();
    
    // Обновление интерфейса
    loadGroupsData();
    loadDashboardData();
    
    // Закрытие модального окна
    document.getElementById('groupModal').classList.remove('active');
    
    // Уведомление
    showToast(`Группа "${name}" создана!`, 'success');
}

// Генерация кода группы
function generateGroupCode(groupName) {
    const prefix = groupName.replace(/[^a-zA-Zа-яА-Я0-9]/g, '').substring(0, 3).toUpperCase();
    const randomNum = Math.floor(100 + Math.random() * 900);
    const year = new Date().getFullYear();
    return `${prefix}-${year}-${randomNum}`;
}

// Копирование кода группы
function copyGroupCode(code) {
    navigator.clipboard.writeText(code).then(() => {
        showToast(`Код "${code}" скопирован`, 'success');
    });
}

// Загрузка данных групп
function loadGroupsData() {
    const container = document.getElementById('groupsList');
    if (!container) return;
    
    if (teacherData.groups.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <p>Нет созданных групп</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = teacherData.groups.map(group => {
        const students = teacherData.students.filter(s => s.group === group.name);
        const studentCount = students.length;
        
        return `
            <div class="group-card">
                <div class="group-header">
                    <div class="group-title">
                        <h4>${group.name}</h4>
                        <p>${group.description}</p>
                    </div>
                    <div class="group-code" onclick="copyGroupCode('${group.code}')">
                        ${group.code}
                    </div>
                </div>
                
                <div class="group-stats">
                    <div class="stat-item">
                        <span class="stat-number">${studentCount}</span>
                        <span class="stat-label">Учеников</span>
                    </div>
                </div>
                
                <div class="group-actions">
                    <button class="btn-secondary" onclick="deleteGroup(${group.id})">
                        <i class="fas fa-trash"></i> Удалить
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

// Удаление группы
function deleteGroup(groupId) {
    if (confirm('Удалить эту группу? Ученики останутся без группы.')) {
        const group = teacherData.groups.find(g => g.id === groupId);
        
        // Убираем группу у учеников
        teacherData.students.forEach(student => {
            if (student.group === group?.name) {
                student.group = '';
            }
        });
        
        teacherData.groups = teacherData.groups.filter(g => g.id !== groupId);
        saveTeacherData();
        
        loadGroupsData();
        loadStudentsData();
        loadDashboardData();
        
        showToast('Группа удалена', 'success');
    }
}

// Показать модальное окно добавления ученика
function showStudentModal() {
    const modal = document.getElementById('studentModal');
    modal.classList.add('active');
    
    // Сброс формы
    document.getElementById('newStudentName').value = '';
    document.getElementById('newStudentSchool').value = '';
    
    // Обновление селекта групп
    updateNewStudentGroupSelect();
}

// Обновление селекта групп для нового ученика
function updateNewStudentGroupSelect() {
    const select = document.getElementById('newStudentGroup');
    if (!select) return;
    
    select.innerHTML = '<option value="">Выберите группу</option>';
    
    teacherData.groups.forEach(group => {
        const option = document.createElement('option');
        option.value = group.name;
        option.textContent = group.name;
        select.appendChild(option);
    });
}

// Сохранение нового ученика
function saveNewStudent() {
    const name = document.getElementById('newStudentName').value.trim();
    const group = document.getElementById('newStudentGroup').value;
    const school = document.getElementById('newStudentSchool').value.trim();
    
    if (!name) {
        showToast('Введите ФИО ученика', 'warning');
        return;
    }
    
    const newStudent = {
        id: teacherData.students.length + 1,
        name: name,
        group: group,
        school: school,
        models: 0,
        status: 'active'
    };
    
    teacherData.students.push(newStudent);
    saveTeacherData();
    
    // Обновление интерфейса
    loadStudentsData();
    loadDashboardData();
    
    // Закрытие модального окна
    document.getElementById('studentModal').classList.remove('active');
    
    // Уведомление
    showToast(`Ученик "${name}" добавлен!`, 'success');
}

// Загрузка данных учеников
function loadStudentsData() {
    const container = document.getElementById('studentsTableBody');
    if (!container) return;
    
    if (teacherData.students.length === 0) {
        container.innerHTML = `
            <tr>
                <td colspan="6" class="empty-state">
                    <p>Нет учеников</p>
                </td>
            </tr>
        `;
        return;
    }
    
    container.innerHTML = teacherData.students.map(student => {
        return `
            <tr>
                <td>${student.name}</td>
                <td>${student.group || '-'}</td>
                <td>${student.school || '-'}</td>
                <td>${student.models}</td>
                <td>
                    <span class="status-badge status-${student.status}">
                        ${student.status === 'active' ? 'Активен' : 'Неактивен'}
                    </span>
                </td>
                <td>
                    <div class="model-actions">
                        <button class="btn-danger" onclick="removeStudent(${student.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

// Фильтрация учеников
function filterStudents(query) {
    const rows = document.querySelectorAll('#studentsTableBody tr');
    query = query.toLowerCase();
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(query) ? '' : 'none';
    });
}

// Удаление ученика
function removeStudent(studentId) {
    if (confirm('Удалить этого ученика?')) {
        teacherData.students = teacherData.students.filter(s => s.id !== studentId);
        saveTeacherData();
        
        loadStudentsData();
        loadDashboardData();
        
        showToast('Ученик удален', 'success');
    }
}

// Загрузка данных моделей
function loadModelsData() {
    const container = document.getElementById('modelsGrid');
    if (!container) return;
    
    let modelsToShow = teacherData.models;
    
    // Применяем фильтр
    if (currentState.filterModel !== 'all') {
        modelsToShow = teacherData.models.filter(m => m.status === currentState.filterModel);
    }
    
    if (modelsToShow.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <p>Нет моделей</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = modelsToShow.map(model => {
        return `
            <div class="model-card">
                <div class="model-preview">
                    <i class="fas fa-cube"></i>
                </div>
                <div class="model-info">
                    <h4>${model.name}</h4>
                    <div class="model-meta">
                        <span>${model.studentName}</span>
                        <span>${model.group}</span>
                    </div>
                    <div class="model-meta">
                        <span>${model.size}</span>
                        <span>${model.date}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1rem;">
                        <span class="status-badge status-${model.status}">
                            ${model.status === 'pending' ? 'На проверке' : 
                              model.status === 'approved' ? 'Принято' : 'Отклонено'}
                        </span>
                        <div class="model-actions">
                            <button class="btn-view" onclick="viewModel(${model.id})">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// Просмотр модели
function viewModel(modelId) {
    const model = teacherData.models.find(m => m.id === modelId);
    if (!model) return;
    
    currentState.currentModelId = modelId;
    
    // Обновление информации в модальном окне
    document.getElementById('viewerModelName').textContent = model.name;
    document.getElementById('viewerStudentName').textContent = model.studentName;
    document.getElementById('viewerGroup').textContent = model.group;
    document.getElementById('viewerModelSize').textContent = model.size;
    document.getElementById('viewerModelDate').textContent = model.date;
    
    const statusElement = document.getElementById('viewerModelStatus');
    statusElement.textContent = model.status === 'pending' ? 'На проверке' : 
                               model.status === 'approved' ? 'Принято' : 'Отклонено';
    
    // Отображение модального окна
    const modal = document.getElementById('modelViewModal');
    modal.classList.add('active');
    
    // Загрузка демо-модели
    loadDemoModel();
}

// Загрузка демо-модели
function loadDemoModel() {
    const viewer = document.getElementById('modelViewer');
    if (!viewer) return;
    
    viewer.innerHTML = `
        <div style="text-align: center; color: white;">
            <i class="fas fa-cube fa-5x" style="color: #3D7BBA;"></i>
            <h4>3D Модель</h4>
            <p>Демо-режим просмотра</p>
        </div>
    `;
}

// Принятие модели
function approveCurrentModel() {
    if (!currentState.currentModelId) return;
    
    const model = teacherData.models.find(m => m.id === currentState.currentModelId);
    if (!model) return;
    
    model.status = 'approved';
    saveTeacherData();
    
    // Обновление интерфейса
    loadModelsData();
    loadDashboardData();
    
    // Закрытие модального окна
    document.getElementById('modelViewModal').classList.remove('active');
    
    // Уведомление
    showToast(`Модель "${model.name}" принята!`, 'success');
}

// Отклонение модели
function rejectCurrentModel() {
    if (!currentState.currentModelId) return;
    
    const model = teacherData.models.find(m => m.id === currentState.currentModelId);
    if (!model) return;
    
    model.status = 'rejected';
    saveTeacherData();
    
    // Обновление интерфейса
    loadModelsData();
    loadDashboardData();
    
    // Закрытие модального окна
    document.getElementById('modelViewModal').classList.remove('active');
    
    // Уведомление
    showToast(`Модель "${model.name}" отклонена`, 'warning');
}

// Показать модальное окно создания задания
function showHomeworkModal() {
    const modal = document.getElementById('homeworkModal');
    modal.classList.add('active');
    
    // Сброс формы
    document.getElementById('homeworkTitle').value = '';
    document.getElementById('homeworkDescription').value = '';
    document.getElementById('homeworkDueDate').value = '';
    
    // Обновление селекта групп
    updateHomeworkGroupSelect();
}

// Обновление селекта групп для задания
function updateHomeworkGroupSelect() {
    const select = document.getElementById('homeworkGroup');
    if (!select) return;
    
    select.innerHTML = '<option value="">Выберите группу</option>';
    
    teacherData.groups.forEach(group => {
        const option = document.createElement('option');
        option.value = group.name;
        option.textContent = group.name;
        select.appendChild(option);
    });
}

// Сохранение нового задания
function saveNewHomework() {
    const title = document.getElementById('homeworkTitle').value.trim();
    const description = document.getElementById('homeworkDescription').value.trim();
    const dueDate = document.getElementById('homeworkDueDate').value;
    const group = document.getElementById('homeworkGroup').value;
    
    if (!title) {
        showToast('Введите название задания', 'warning');
        return;
    }
    
    if (!dueDate) {
        showToast('Выберите срок сдачи', 'warning');
        return;
    }
    
    if (!group) {
        showToast('Выберите группу', 'warning');
        return;
    }
    
    const newHomework = {
        id: teacherData.homework.length + 1,
        title: title,
        description: description,
        dueDate: dueDate,
        group: group,
        created: new Date().toISOString().split('T')[0],
        submissions: 0
    };
    
    teacherData.homework.push(newHomework);
    saveTeacherData();
    
    // Обновление интерфейса
    loadHomeworkData();
    
    // Закрытие модального окна
    document.getElementById('homeworkModal').classList.remove('active');
    
    // Уведомление
    showToast(`Задание "${title}" создано!`, 'success');
}

// Загрузка данных заданий
function loadHomeworkData() {
    const container = document.getElementById('homeworkList');
    if (!container) return;
    
    if (teacherData.homework.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <p>Нет заданий</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = teacherData.homework.map(hw => {
        return `
            <div class="homework-card">
                <div class="homework-header">
                    <div class="homework-title">
                        <h4>${hw.title}</h4>
                        <p>${hw.description}</p>
                    </div>
                </div>
                <div class="homework-info">
                    <span>Группа: ${hw.group}</span>
                    <span>Срок: ${hw.dueDate}</span>
                    <span>Сдано: ${hw.submissions}</span>
                </div>
                <div class="homework-actions">
                    <button class="btn-danger" onclick="deleteHomework(${hw.id})">
                        <i class="fas fa-trash"></i> Удалить
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

// Удаление задания
function deleteHomework(homeworkId) {
    if (confirm('Удалить это задание?')) {
        teacherData.homework = teacherData.homework.filter(h => h.id !== homeworkId);
        saveTeacherData();
        loadHomeworkData();
        showToast('Задание удалено', 'success');
    }
}

// Фильтрация групп
function filterGroups(query) {
    const cards = document.querySelectorAll('.group-card');
    query = query.toLowerCase();
    
    cards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(query) ? 'block' : 'none';
    });
}

// Показать уведомление
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 
                         type === 'error' ? 'exclamation-circle' : 
                         type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
        <div class="toast-content">
            <p>${message}</p>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    container.appendChild(toast);
    
    // Автоматическое удаление через 3 секунды
    setTimeout(() => {
        if (toast.parentElement) {
            toast.remove();
        }
    }, 3000);
}

// Экспорт функций для использования в HTML
window.copyGroupCode = copyGroupCode;
window.showGroupModal = showGroupModal;
window.showStudentModal = showStudentModal;
window.showHomeworkModal = showHomeworkModal;
window.deleteGroup = deleteGroup;
window.removeStudent = removeStudent;
window.viewModel = viewModel;
window.deleteHomework = deleteHomework;
window.switchSection = switchSection;

// Инициализация при загрузке страницы
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTeacherApp);
} else {
    initTeacherApp();
}