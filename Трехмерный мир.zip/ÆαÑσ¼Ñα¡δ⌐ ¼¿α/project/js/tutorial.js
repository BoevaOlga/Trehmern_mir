// js/tutorial.js
// Логика страницы обучения

document.addEventListener('DOMContentLoaded', function() {
    initTutorialPage();
});

function initTutorialPage() {
    console.log('📚 Страница обучения загружена');
    
    // Здесь можно добавить логику для страницы обучения
    // Например, интерактивные элементы, подсветку шагов и т.д.
    
    // Пример: добавление интерактивности к изображениям
    const images = document.querySelectorAll('.content-img');
    images.forEach(img => {
        img.addEventListener('click', function() {
            this.classList.toggle('zoomed');
        });
    });
    
    // Пример: подсветка текущего шага при скролле
    const sections = document.querySelectorAll('.blue-insert');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.boxShadow = '0 15px 35px rgba(93, 140, 174, 0.4)';
            } else {
                entry.target.style.boxShadow = '0 10px 30px rgba(93, 140, 174, 0.3)';
            }
        });
    }, { threshold: 0.5 });
    
    sections.forEach(section => {
        observer.observe(section);
    });
    
    console.log('✅ Страница обучения инициализирована');
}